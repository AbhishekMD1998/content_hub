import { NavLink, Outlet } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

export default function Layout() {
  const { isAdmin, logout } = useAuth();

  return (
    <div className="app-shell">
      <header className="site-header">
        <NavLink to="/" className="brand">
          <span className="brand-mark">CH</span>
          <span>Content Hub</span>
        </NavLink>
        <nav className="main-nav" aria-label="Main">
          <NavLink to="/" end>
            Dashboard
          </NavLink>
          <NavLink to="/blogs">Blogs</NavLink>
          <NavLink to="/articles">Articles</NavLink>
          {isAdmin ? (
            <>
              <NavLink to="/admin">Admin</NavLink>
              <button type="button" className="btn btn-ghost" onClick={logout}>
                Log out
              </button>
            </>
          ) : (
            <NavLink to="/admin/login" className="nav-admin">
              Admin
            </NavLink>
          )}
        </nav>
      </header>
      <main className="site-main">
        <Outlet />
      </main>
      <footer className="site-footer">
        <p>© {new Date().getFullYear()} Content Hub — blogs by admin, articles by editorial.</p>
      </footer>
    </div>
  );
}
